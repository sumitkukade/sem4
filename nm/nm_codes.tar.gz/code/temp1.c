#include<stdio.h>
void main()
{
  int a=1;
  float b=1.28,c;
  c=b-a;
  printf("%f",c);

}
